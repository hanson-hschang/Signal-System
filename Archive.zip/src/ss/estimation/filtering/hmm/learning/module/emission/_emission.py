from typing import Generic, assert_never
from collections.abc import Callable

import torch
import torch.nn as nn

from ss.estimation.filtering.hmm.learning.module.emission.config import (
    EmissionConfig,
)
from ss.estimation.filtering.hmm.learning.module.filter.config import (
    DualFilterConfig,
)
from ss.utility.learning.module import BaseLearningModule
from ss.utility.learning.parameter.probability import ProbabilityParameter
from ss.utility.learning.parameter.transformer import T
from ss.utility.learning.parameter.transformer.config import TC


@torch.compile
def to_probability(
    estimation_trajectory: torch.Tensor,
) -> torch.Tensor:
    return nn.functional.normalize(
        estimation_trajectory,
        p=1,
        dim=-1,
    )


class EmissionModule(BaseLearningModule[EmissionConfig[TC]], Generic[T, TC]):
    def __init__(
        self,
        config: EmissionConfig[TC],
        filter_config: DualFilterConfig,
    ) -> None:
        super().__init__(config)
        self._state_dim = filter_config.state_dim
        self._discrete_observation_dim = filter_config.discrete_observation_dim

        self._matrix = ProbabilityParameter[T, TC](
            self._config.matrix.probability_parameter,
            (self._state_dim, self._discrete_observation_dim),
        )

        self._forward: Callable[[torch.Tensor], torch.Tensor]
        self._init_forward()

    def _init_forward(self) -> None:
        match self._config.observation.option:
            case self._config.observation.Option.CATEGORY:
                self._forward = self._forward_category
            case self._config.observation.Option.PROBABILITY:
                self._forward = self._forward_probability
            case _ as _option:
                assert_never(_option)

    @property
    def matrix_parameter(
        self,
    ) -> ProbabilityParameter[T, TC]:
        return self._matrix

    @property
    def matrix(self) -> torch.Tensor:
        matrix: torch.Tensor = self._matrix()
        return matrix

    @matrix.setter
    def matrix(self, matrix: torch.Tensor) -> None:
        self._matrix.set_value(matrix)

    @torch.compile
    def _forward_category(
        self, observation_trajectory: torch.Tensor
    ) -> torch.Tensor:
        # observation_trajectory: (batch_size, observation_dim=1, horizon)

        emission_matrix = self.matrix  # (state_dim, discrete_observation_dim)

        # Get emission based on each observation in the trajectory
        emission_trajectory = torch.moveaxis(
            emission_matrix[:, observation_trajectory[:, 0, :]], 0, 1
        )  # (batch_size, state_dim, horizon)

        return emission_trajectory

    @torch.compile
    def _forward_probability(
        self,
        observation_trajectory: torch.Tensor,
    ) -> torch.Tensor:
        # observation_trajectory: (batch_size, discrete_observation_dim, horizon)  # noqa: E501

        emission_matrix = (
            self.matrix
        )  # (state_dim, discrete_observation_dim)  # noqa: E501

        # emission_trajectory = torch.matmul(
        #     observation_trajectory,  # (batch_size, horizon, discrete_observation_dim)  # noqa: E501
        #     emission_matrix.T,  # (discrete_observation_dim, state_dim)
        # )  # (batch_size, horizon, state_dim)
        emission_trajectory = torch.einsum(
            "bmt, dm -> bdt",
            observation_trajectory,  # (batch_size, discrete_observation_dim, horizon)  # noqa: E501
            emission_matrix,  # (state_dim, discrete_observation_dim)
        )

        return emission_trajectory

    def forward(
        self,
        observation_trajectory: torch.Tensor,
    ) -> torch.Tensor:
        emission_trajectory = self._forward(
            observation_trajectory,  # (batch_size, observation_dim=1, horizon)
        )  # (batch_size, state_dim, horizon)

        return emission_trajectory

    def at_inference(
        self, observation_trajectory: torch.Tensor, batch_size: int = 1
    ) -> torch.Tensor:
        observation_trajectory = self._validate_observation_shape(
            observation_trajectory, batch_size=batch_size
        )
        return self.forward(observation_trajectory)

    def _validate_observation_shape(
        self, observation: torch.Tensor, batch_size: int = 1
    ) -> torch.Tensor:
        match self._config.observation.option:
            case self._config.observation.Option.CATEGORY:
                if observation.ndim == 1:
                    observation = observation.unsqueeze(
                        0
                    )  # (batch_size=1, observation_dim=1)
                if observation.ndim == 2:
                    observation = observation.unsqueeze(
                        -1
                    )  # (batch_size, observation_dim=1, horizon=1)
                assert observation.ndim == 3, (
                    f"observation must be in the shape of "
                    f"(batch_size, observation_dim=1, horizon). "
                    f"observation given has the shape of {observation.shape}."
                )
                assert observation.shape[0:2] == (batch_size, 1), (
                    f"observation must be in the shape of "
                    f"(batch_size={batch_size}, observation_dim=1, horizon). "
                    f"observation given has the shape = {observation.shape}."
                )
            case self._config.observation.Option.PROBABILITY:
                if observation.ndim == 1:
                    observation = observation.unsqueeze(
                        0
                    )  # (batch_size=1, discrete_observation_dim)
                if observation.ndim == 2:
                    observation = observation.unsqueeze(
                        -1
                    )  # (batch_size, discrete_observation_dim, horizon=1).  # noqa: E501
                assert observation.ndim == 3, (
                    f"observation must be in the shape of "
                    f"(batch_size={batch_size}, discrete_observation_dim, horizon). "  # noqa: E501
                    f"observation given has the shape = {observation.shape}."
                )
                assert observation.shape[0] == batch_size, (
                    f"observation must be in the shape of "
                    f"(batch_size={batch_size}, discrete_observation_dim, horizon). "  # noqa: E501
                    f"observation given has the shape = {observation.shape}."
                )
            case _ as _option:
                assert_never(_option)
        return observation
